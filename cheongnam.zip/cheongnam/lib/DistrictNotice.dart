import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'main.dart';

class DistrictNotice extends StatefulWidget {
  @override
  _DistrictNoticeState createState() => _DistrictNoticeState();
}

class _DistrictNoticeState extends State<DistrictNotice> {
  @override
  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldkey,
        backgroundColor: theme_white,
        appBar: AppBar(
          // automaticallyImplyLeading: false,
          // titleSpacing: 0,
          toolbarHeight: 80,
          title: Text(
            '구역공지',
            style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w600, color: theme_grey),
          ),
          centerTitle: true,
          leading: Padding(
            padding: const EdgeInsets.only(left: 20.0),
            child: IconButton(
                icon: Icon(
                  Icons.chevron_left,
                  color: theme_grey,
                ),
                iconSize: 33,
                onPressed: () => Get.back()),
          ),
          backgroundColor: theme_white,
          elevation: 0,
        ),
        body: _CardList());
  }

  Widget _CardList() {
    return ListView.builder(
      itemCount: 10,
      itemBuilder: (_, index) {
        return _listBuilder("1월 3번째 주 구역예배", "담임목사", "2020-01-15");
      },
    );
  }

  Widget _listBuilder(String title, String author, String date) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, right: 15, top: 3, bottom: 3),
      child: Card(
        elevation: 3,
        semanticContainer: true,
        clipBehavior: Clip.antiAliasWithSaveLayer,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: ListTile(
          title: Padding(
            padding: const EdgeInsets.only(top: 13, left: 10),
            child: Text(title),
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(left: 10, top: 3, bottom: 10),
            child: Row(
              children: [
                Text(author + "  "),
                Text(date),
              ],
            ),
          ),
          onTap: null,
        ),
      ),
    );
  }
}