import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:ui' as ui;
import 'News.dart';
import 'WorshipService.dart';
import 'DistrictNotice.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Cheongnam',
      home: home(),
    );
  }
}

final Color theme_white = Color(0xffefefef);
final Color theme_grey = Color(0xff5c5d5e);
final Color theme_beige = Color(0xffc9b8a9);
final Color theme_blue = Color(0xff2776e0);

class home extends StatefulWidget {
  @override
  _homeState createState() => _homeState();
}

class _homeState extends State<home> {
  int _index = 0;
  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldkey,
      drawer: Theme(
        data: Theme.of(context).copyWith(
          canvasColor: Colors
              .white60, //or any other color you want. e.g Colors.blue.withOpacity(0.5)
        ),
        child: MainDrawer("홍길동", "./assets/images/cross.jpg"),
      ),
      appBar: AppBar(
        toolbarHeight: 80,
        title:
            SizedBox(height: 55, child: Image.asset('assets/images/logo.png')),
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.only(left: 20.0),
          child: IconButton(
              icon: Icon(
                Icons.menu,
                color: theme_grey,
              ),
              iconSize: 28,
              onPressed: () => _scaffoldkey.currentState.openDrawer()),
        ),
        backgroundColor: theme_white,
        elevation: 0,
      ),
      backgroundColor: theme_white,
      body: Column(
        children: <Widget>[
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.3, // card height
            child: PageView.builder(
              itemCount: 3,
              controller: PageController(viewportFraction: 0.87),
              onPageChanged: (int index) => setState(() => _index = index),
              itemBuilder: (_, i) {
                return Transform.scale(
                  scale: i == _index ? 1 : 0.93,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: Card(
                      elevation: 6,
                      semanticContainer: true,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      child: Center(
                        child: Image.asset("assets/images/img${i + 1}.jpg",
                            width: 1000, height: 1000, fit: BoxFit.cover),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.24,
            width: MediaQuery.of(context).size.width * 0.87,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                menuCard(
                    title: "교회소식",
                    titleEng: "News",
                    color: theme_blue,
                    route: News()),
                menuCard(
                    title: "예배공지",
                    titleEng: "Worship Sevice",
                    color: theme_beige,
                    route: WorshipService()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.24,
              width: MediaQuery.of(context).size.width * 0.87,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  menuCard(
                      title: "구역공지",
                      titleEng: "District Notice",
                      color: theme_beige,
                      route: DistrictNotice()),
                  menuCard(
                      title: "교회정보",
                      titleEng: "Church Info",
                      color: theme_beige)
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget menuCard({String title, String titleEng, Color color, Widget route}) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.41,
      child: GestureDetector(
        onTap: () => Get.to(route, transition: Transition.cupertino),
        child: Card(
            shadowColor: color,
            elevation: 6,
            color: color,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.only(left: 20, right: 10, bottom: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                            fontSize: 22,
                            color: Colors.white,
                            fontWeight: FontWeight.w600),
                        textAlign: TextAlign.left,
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        titleEng,
                        style: TextStyle(fontSize: 12, color: Colors.white70),
                        textAlign: TextAlign.left,
                      ),
                    ],
                  ),
                  Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 30),
                      child: Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                offset: const Offset(3.0, 3.0),
                                blurRadius: 10.0,
                                spreadRadius: 2.0,
                              ),
                            ]),
                        child: IconButton(
                          icon: Icon(
                            Icons.arrow_forward,
                            color: theme_grey,
                          ),
                          onPressed: null,
                        ),
                      ),
                    ),
                  ]),
                ],
              ),
            )),
      ),
    );
  }

  Widget MainDrawer(String profileName, String profileImg) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          Stack(
            alignment: Alignment.bottomCenter,
            children: <Widget>[
              Container(
                // width: double.infinity,
                height: 250,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(profileImg), fit: BoxFit.cover)),
                child: ClipRRect(
                  // make sure we apply clip it properly
                  child: BackdropFilter(
                    filter: ui.ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                    child: Container(
                      alignment: Alignment.center,
                      color: Colors.grey.withOpacity(0.1),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(60.0),
                child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 50,
                    backgroundImage: ExactAssetImage(profileImg)),
              ),
              Padding(
                padding: const EdgeInsets.all(25.0),
                child: Text(
                  profileName,
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
              )
            ],
          ),
          SizedBox(height: 20),
          ListTile(
            onTap: () => Navigator.pop(context),
            leading: Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Icon(Icons.account_circle),
            ),
            title: Text(
              '프로필',
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ),
          ListTile(
            onTap: () => Navigator.pop(context),
            leading: Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Icon(Icons.exit_to_app),
            ),
            title: Text(
              '로그아웃',
              style: TextStyle(
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
